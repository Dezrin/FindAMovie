<?php
include "includes/header.php";
?>

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Submit a new movie link to Find a Movie</h1>
                <p class="lead">Please use the Choose file button below and text box to add a new movie.</p>
                <ul class="list-unstyled">
				<center>
				<form method="POST" action="post-movie.php" enctype="multipart/form-data">
                    <li><input type="text" style="width:50%;" name="movietitle" id="movietitle" placeholder="Movie Title" required></li><br>
					<li><input type="text" style="width:50%;" name="movielink" id="movielink" placeholder="Movie Link" required></li><br>
					<li><input type="text" style="width:50%;" name="movieyear" id="movieyear" placeholder="Move Year" required></li><br>
					<!--<p class="small">Select cover image</p>
                    <li><input type="file" name="fileToUpload" id="fileToUpload"></li><br>
					<p class="small" style="color:red;">Please ensure the image is as close to 750px X 450px as possible!</p>-->
					<li><button class="btn btn-success" type="submit" name="submit" id="submit"><span class="glyphicon glyphicon-ok"></span> Submit</button></li><br>
					<li><a href="index.php"><button class="btn btn-danger" type="button" name="cancel"><span class="glyphicon glyphicon-remove"></span> Cancel</button></a></li>
                </form>
				</center>
				</ul>
            </div>
        </div>
        <!-- /.row -->

<?php
include "includes/footer.php";
?>