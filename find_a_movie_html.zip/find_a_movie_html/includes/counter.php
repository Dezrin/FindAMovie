<?php
$servername = "localhost";
$username = "root";
$password = "password01";
$dbname = "findamovie";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//Total Customer Counter
$sql="SELECT * FROM movie";
$result = $conn->query($sql);
$rowcount=mysqli_num_rows($result);
$count_movies = $rowcount;

?>