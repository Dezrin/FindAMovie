<?php
$servername = "localhost";
$username = "root";
$password = "password01";
$dbname = "findamovie";

$movieid = $_GET['movie_id'];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM movie WHERE ID = '$movieid'";
$result = mysqli_query($conn, $sql);

while($row = mysqli_fetch_array($result)) {
		$count_upvotes = $row['4'];
		$count_downvotes = $row['5'];
}

if (strpos($count_upvotes, '0') !==false){
	$sql1 = "UPDATE movie SET up_votes = '1' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '1') !==false){
	$sql1 = "UPDATE movie SET up_votes = '2' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '2') !==false){
	$sql1 = "UPDATE movie SET up_votes = '3' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '3') !==false){
	$sql1 = "UPDATE movie SET up_votes = '4' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '4') !==false){
	$sql1 = "UPDATE movie SET up_votes = '5' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '5') !==false){
	$sql1 = "UPDATE movie SET up_votes = '6' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '6') !==false){
	$sql1 = "UPDATE movie SET up_votes = '7' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '7') !==false){
	$sql1 = "UPDATE movie SET up_votes = '8' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '8') !==false){
	$sql1 = "UPDATE movie SET up_votes = '9' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '9') !==false){
	$sql1 = "UPDATE movie SET up_votes = '10' WHERE ID = '$movieid'";
} elseif (strpos($count_upvotes, '10') !==false){
	header('location:index.php?error=Error. This movie has the maximum upvotes applied.');
} else {
	$sql1 = "UPDATE movie SET up_votes = '1' WHERE ID = '$movieid'";
}

if ($conn->query($sql1) === TRUE) {
    header('location:index.php?msg=Success! You have up voted this movie.');
} else {
    var_dump($sql1);
}

mysqli_close($conn);
?>