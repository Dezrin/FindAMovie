<?php
include "includes/header.php";
?>

<?php
//PHP Script to GET movie records from database
$servername = "localhost";
$username = "root";
$password = "password01";
$dbname = "findamovie";

$movieid = $_GET['movie_id'];

 $conn = new mysqli($servername, $username, $password, $dbname);

 if (!$conn) {
	  die("Connection failed: " . mysqli_connect_error());
 }

 $sql = "SELECT * FROM movie WHERE ID = '$movieid'";
 $result = mysqli_query($conn, $sql);

while($row = mysqli_fetch_array($result)) {
	$movie_link = $row['2'];
}
mysqli_close($conn);
?>

        <div class="row">
                <h1>Find a Movie - Player</h1>
				<center>
				<style type="text/css">
				body, html
				{
					margin: 0; padding: 0; height: 100%;
				}

				#content
				{
					position:absolute; left: 0; right: 0; bottom: 0; top: 0px; 
				}
				</style>
				<div id="content">
				<iframe src="<?php echo $movie_link; ?>" width="100%" height="100%"></iframe>
				</div>
				</center>
        </div>
        <!-- /.row -->

<?php
include "includes/footer.php";
?>