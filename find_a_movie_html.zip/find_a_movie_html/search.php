<?php 
include "includes/header.php";
$getsearch = $_GET['search'];
?>
<form method="GET" action="search.php">
<div id="custom-search-input">
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="Search for Movie or TV Show Title..." name="search" id="search" />
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </span>
                </div>
            </div>
			</form>
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Find a Movie
                    <small>Search Results: <?php echo $getsearch; ?></small>
                </h1>
            </div>
        </div>
        <!-- /.row -->
<?php
$msg = $_GET['msg'];
if (isset($msg)) {
echo '<div class="alert alert-success alert-dismissible" role="alert" style="margin-bottom:120px;">';
echo '<button type="button" class="close" onClick="$().alert(\'close\');" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
echo '<strong><i class="glyphicon glyphicon-ok"></i> </strong>' . $msg . '</div>';
} else {
}
?>
<!-- Projects Row -->
<div class="row">
		<?php
		//PHP Script to GET movie records from database
		$servername = "localhost";
		$username = "root";
		$password = "password01";
		$dbname = "findamovie";
		
		 $conn = new mysqli($servername, $username, $password, $dbname);

		 if (!$conn) {
		      die("Connection failed: " . mysqli_connect_error());
		 }

		 $sql="SELECT * FROM movie WHERE (`movie_name` LIKE '%".$getsearch."%')";
		 $result = mysqli_query($conn, $sql);

		      while($row = mysqli_fetch_array($result)) {
						//Connection to the OMDB API
						$xml = simplexml_load_file("http://www.omdbapi.com/?t=" . urlencode($row['1']) . "&y=" . $row['6'] . "&r=xml&apikey=52a8f26a");

						//List XML API functions
						$title = $xml->movie[0]['title'];
						$year = $xml->movie[0]['year'];
						$rated = $xml->movie[0]['rated'];
						$released = $xml->movie[0]['released'];
						$runtime = $xml->movie[0]['runtime'];
						$genre = $xml->movie[0]['genre'];
						$director = $xml->movie[0]['director'];
						$writer = $xml->movie[0]['writer'];
						$actors = $xml->movie[0]['actors'];
						$plot = $xml->movie[0]['plot'];
						$language = $xml->movie[0]['language'];
						$country = $xml->movie[0]['country'];
						$awards = $xml->movie[0]['awards'];
						$poster = $xml->movie[0]['poster'];
						$metascore = $xml->movie[0]['metascore'];
						$imdbrating = $xml->movie[0]['imdbrating'];
						$imdbvotes = $xml->movie[0]['imdbvotes'];
						$imdbID = $xml->movie[0]['imdbID'];
						$type = $xml->movie[0]['type'];
						
						//If to display default artwork if none available
						if ($row['3'] == !NULL){
							
						} elseif (strpos($row['3'], "N/A") !==false) {
							$row['3'] = "images/artworkdefault.png";
						} else {
							$row['3'] = "images/artworkdefault.png";
						}
						
						echo '<center><div class="col-md-3 portfolio-item">';
						echo '<a href="details.php?movie_id=' . $row['0'] . '" alt="' . $row['1'] . '">';
						echo '<div class="imgdiv"><img class="bw pic" style="box-shadow: 4px 4px 20px #222;" src="' . $row['3'] .'" alt="' . $row['1'] . '"/></div>';
						echo '</a>';
						echo '<div style="min-height:40px;vertical-align:top;">';
						echo '<br><b><center><p style="float:middle;">' . $row['1'] .'</p></center></b>';
						echo '<center><p>' . $released . '</p></center>';
						echo '<center><b><p style="float:middle;">Rated: ' . $rated . ' | Runtime: ' . $runtime . '</p></center></b>';
						echo '<a href="adddownvote.php?movie_id=' . $row['0'] . '"><button class="btn btn-large" type="button" style="color:red;float:right;"><span class="glyphicon glyphicon-remove-circle"></span>Down Vote</button></a>';
						echo '<a href="addupvote.php?movie_id=' . $row['0'] . '"><button class="btn btn-large" type="button" style="color:green;float:left;"><span class="glyphicon glyphicon-ok-circle"></span>Up Vote</button></a>';
						echo '</div>';
						echo '<br></div></center>';
						}
					mysqli_close($conn);
		?>

		</div>
<?php
include "includes/footer.php";
?>