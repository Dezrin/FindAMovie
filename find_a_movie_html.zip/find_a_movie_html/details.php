<?php
//PHP Script to GET movie records from database
$servername = "localhost";
$username = "root";
$password = "password01";
$dbname = "findamovie";

$movieid = $_GET['movie_id'];

$conn = new mysqli($servername, $username, $password, $dbname);

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM movie WHERE ID = '$movieid'";

$result = mysqli_query($conn, $sql);

while($row = mysqli_fetch_array($result)) {
$film_title = $row['1'];
$film_year = $row['6'];
$film_link = $row['2'];
}

//Connection to the OMDB API
$xml = simplexml_load_file("http://www.omdbapi.com/?t=" . urlencode($film_title) . "&y=" . $film_year . "&r=xml&apikey=52a8f26a");

//List XML API functions
$title = $xml->movie[0]['title'];
$year = $xml->movie[0]['year'];
$rated = $xml->movie[0]['rated'];
$released = $xml->movie[0]['released'];
$runtime = $xml->movie[0]['runtime'];
$genre = $xml->movie[0]['genre'];
$director = $xml->movie[0]['director'];
$writer = $xml->movie[0]['writer'];
$actors = $xml->movie[0]['actors'];
$plot = $xml->movie[0]['plot'];
$language = $xml->movie[0]['language'];
$country = $xml->movie[0]['country'];
$awards = $xml->movie[0]['awards'];
$poster = $xml->movie[0]['poster'];
$metascore = $xml->movie[0]['metascore'];
$imdbrating = $xml->movie[0]['imdbrating'];
$imdbvotes = $xml->movie[0]['imdbvotes'];
$imdbID = $xml->movie[0]['imdbID'];
$type = $xml->movie[0]['type'];

?>
<?php
include "includes/header.php";
?>

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Movie Details: <?php echo $title; ?></h1>
                <ul class="list-unstyled">
				<center>
                    <li>You are about to watch: <?php echo $title; ?> | Run Time: <?php echo $runtime; ?> | Released: <?php echo $released; ?></li><br>
					<li><img class="img-responsive" src="<?php echo $poster; ?>"/></li><br>
                    <li>Plot: <?php echo $plot; ?></li><br>
					<li>Actors: <?php echo $actors; ?> | Writer: <?php echo $writer; ?> | Director: <?php echo $director; ?></li><br>
					<li><a href="<?php echo $film_link; ?>"><button class="btn btn-big btn-success btn-block" type="button" name="cancel" style="font-size:24px;"> Watch Now</button></a></li>
					<br>
					<li><img class="img-responsive" src="http://image.prntscr.com/image/0b70db7e098049f09e2b44627d9ed876.png"/></li>
				</center>
				</ul>
            </div>
        </div>
        <!-- /.row -->

<?php
include "includes/footer.php";
?>